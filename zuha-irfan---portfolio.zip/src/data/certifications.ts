import { Certification } from '../types';

export const certificationsData: Certification[] = [
  {
    id: "corvit-navttc-ai",
    title: "Artificial Intelligence Course",
    issuer: "Corvit Institute / NAVTTC",
    date: "Feb 2026 – May 2026",
    roleOrSpecialization: "Artificial Intelligence & Applied Machine Learning",
    credentialUrl: "#", // Placeholder: replace with actual verification URL
    skillsLearned: [
      "Machine Learning Fundamentals",
      "Neural Network Architecture",
      "Python for Data Science",
      "Model Training & Evaluation",
      "Natural Language Processing"
    ],
    verificationId: "CRV-NAVTTC-2026-AI-094",
    description:
      "Comprehensive government-partnered training covering machine learning foundations, deep learning concepts with Python/PyTorch, NLP, and applied predictive modeling."
  },
  {
    id: "galvanai-internship",
    title: "Internship Certificate",
    issuer: "GalvanAI",
    date: "August 28, 2026",
    roleOrSpecialization: "Intern — 2-Month Internship Program",
    credentialUrl: "#", // Placeholder: replace with actual verification URL
    skillsLearned: [
      "AI & Automation Pipelines",
      "Process Optimization",
      "Technical Workflow Troubleshooting",
      "Cross-Functional Collaboration"
    ],
    verificationId: "GLV-INT-2026-0828",
    description:
      "Awarded upon successful completion of the intensive 2-month professional internship program at GalvanAI, engaging in applied intelligent automation tasks and collaborative problem-solving."
  }
];

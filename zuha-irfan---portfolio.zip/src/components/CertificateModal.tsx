import React, { useEffect } from 'react';
import { Certification } from '../types';
import { X, Award, ExternalLink, ShieldCheck, Calendar, CheckCircle2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface CertificateModalProps {
  certificate: Certification | null;
  onClose: () => void;
}

export const CertificateModal: React.FC<CertificateModalProps> = ({ certificate, onClose }) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };

    if (certificate) {
      document.body.style.overflow = 'hidden';
      window.addEventListener('keydown', handleKeyDown);
    } else {
      document.body.style.overflow = '';
    }

    return () => {
      document.body.style.overflow = '';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [certificate, onClose]);

  if (!certificate) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-[#1F1B2D]/60 backdrop-blur-sm transition-opacity"
        />

        {/* Modal Window */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          transition={{ duration: 0.25, ease: [0.22, 1, 0.36, 1] }}
          className="relative w-full max-w-2xl bg-white rounded-3xl p-6 sm:p-10 border border-[#8B5CF6]/20 shadow-2xl z-10 my-8 overflow-hidden"
          role="dialog"
          aria-modal="true"
          aria-labelledby="cert-modal-title"
        >
          {/* Close button */}
          <button
            onClick={onClose}
            className="absolute top-5 right-5 p-2 rounded-full text-[#6B6478] hover:text-[#1F1B2D] hover:bg-[#F6F1FF] transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[#8B5CF6]"
            aria-label="Close certificate modal"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Certificate View Container */}
          <div className="border-2 border-[#DDD6FE] rounded-2xl p-6 sm:p-8 bg-gradient-to-b from-[#FAF8FF] to-white relative mb-6">
            {/* Top Seal */}
            <div className="flex items-center justify-between border-b border-[#8B5CF6]/15 pb-4 mb-6">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-[#EDE9FE] text-[#8B5CF6] flex items-center justify-center">
                  <Award className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-xs font-bold text-[#8B5CF6] tracking-widest uppercase">
                    Official Credential
                  </span>
                  <p className="text-xs text-[#6B6478]">{certificate.issuer}</p>
                </div>
              </div>
              <div className="flex items-center gap-1.5 text-xs text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Verified</span>
              </div>
            </div>

            {/* Title & Recipient */}
            <div className="text-center space-y-2 mb-6">
              <span className="text-xs text-[#6B6478] uppercase tracking-wider font-semibold">
                This Certificate Is Presented To
              </span>
              <h3 className="text-2xl sm:text-3xl font-bold tracking-tight text-[#1F1B2D]">
                Zuha Irfan
              </h3>
              <p className="text-sm text-[#6B6478]">
                For successfully fulfilling the requirements and criteria for:
              </p>
              <h4 id="cert-modal-title" className="text-lg sm:text-xl font-bold text-[#7C3AED] pt-1">
                {certificate.title}
              </h4>
              {certificate.roleOrSpecialization && (
                <p className="text-xs text-[#6B6478] italic">
                  ({certificate.roleOrSpecialization})
                </p>
              )}
            </div>

            {/* Program details & skills */}
            <div className="bg-white/80 rounded-xl p-4 border border-[#8B5CF6]/15 mb-6 text-xs text-[#6B6478] leading-relaxed">
              <p className="mb-3">{certificate.description}</p>
              <div className="space-y-1.5">
                <span className="font-semibold text-[#1F1B2D] block">Core Competencies Certified:</span>
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {certificate.skillsLearned.map((skill) => (
                    <span
                      key={skill}
                      className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-[#FAF8FF] text-[#1F1B2D] border border-[#8B5CF6]/20 font-medium"
                    >
                      <CheckCircle2 className="w-3 h-3 text-[#8B5CF6]" />
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Bottom Meta */}
            <div className="flex flex-col sm:flex-row items-center justify-between text-xs text-[#6B6478] border-t border-[#8B5CF6]/15 pt-4 gap-2">
              <span className="flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-[#8B5CF6]" />
                Issued: {certificate.date}
              </span>
              {certificate.verificationId && (
                <span className="font-mono text-[11px] text-[#8B5CF6]">
                  ID: {certificate.verificationId}
                </span>
              )}
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-end gap-3">
            <button
              onClick={onClose}
              className="w-full sm:w-auto px-5 py-2.5 rounded-full text-sm font-medium text-[#1F1B2D] bg-[#FAF8FF] hover:bg-[#F6F1FF] border border-[#8B5CF6]/20 transition-colors"
            >
              Close Preview
            </button>
            <a
              href={certificate.credentialUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-full text-sm font-medium text-white bg-gradient-to-r from-[#8B5CF6] to-[#7C3AED] hover:from-[#7C3AED] hover:to-[#6D28D9] shadow-sm hover:shadow-md transition-all"
            >
              <span>Verify Official Credential</span>
              <ExternalLink className="w-4 h-4" />
            </a>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};

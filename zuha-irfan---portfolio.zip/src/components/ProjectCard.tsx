import React from 'react';
import { Project } from '../types';
import { Link } from '../context/RouterContext';
import { ProjectMockup } from './ProjectMockup';
import { ArrowUpRight, Calendar } from 'lucide-react';
import { Badge } from './Badge';

interface ProjectCardProps {
  project: Project;
  featured?: boolean;
}

export const ProjectCard: React.FC<ProjectCardProps> = ({ project }) => {
  return (
    <div className="group relative rounded-3xl bg-white border border-[#8B5CF6]/15 p-5 sm:p-7 shadow-xs hover:shadow-xl hover:shadow-[#8B5CF6]/10 hover:-translate-y-1.5 transition-all duration-300 flex flex-col justify-between overflow-hidden">
      {/* Subtle hover gradient ring */}
      <div className="absolute inset-0 rounded-3xl bg-gradient-to-br from-[#8B5CF6]/5 via-transparent to-[#60A5FA]/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none" />

      <div>
        {/* Visual Mockup Header */}
        <div className="relative overflow-hidden rounded-2xl mb-6 bg-[#FAF8FF]">
          <div className="transform transition-transform duration-500 ease-out group-hover:scale-[1.02]">
            <ProjectMockup slug={project.slug} variant="card" />
          </div>
        </div>

        {/* Meta Bar: Category + Year */}
        <div className="flex items-center justify-between gap-2 mb-3">
          <Badge variant="lavender" size="sm">
            {project.category}
          </Badge>
          <span className="flex items-center gap-1 text-xs text-[#6B6478] font-medium">
            <Calendar className="w-3.5 h-3.5 text-[#8B5CF6]" />
            {project.year}
          </span>
        </div>

        {/* Title */}
        <h3 className="text-xl sm:text-2xl font-bold tracking-tight text-[#1F1B2D] group-hover:text-[#8B5CF6] transition-colors mb-2.5">
          <Link to={`/projects/${project.slug}`} className="focus:outline-none focus-visible:ring-2 focus-visible:ring-[#8B5CF6] rounded-md">
            {project.title}
          </Link>
        </h3>

        {/* Description */}
        <p className="text-sm sm:text-base text-[#6B6478] leading-relaxed line-clamp-3 mb-6">
          {project.description}
        </p>
      </div>

      {/* Footer: Tech tags + Case Study Link */}
      <div className="pt-4 border-t border-[#8B5CF6]/10 space-y-4">
        {/* Technology Pills */}
        <div className="flex flex-wrap gap-1.5">
          {project.technologies.slice(0, 4).map((tech) => (
            <span
              key={tech}
              className="text-xs px-2.5 py-1 rounded-full bg-[#FAF8FF] text-[#6B6478] border border-[#8B5CF6]/15 font-medium"
            >
              {tech}
            </span>
          ))}
          {project.technologies.length > 4 && (
            <span className="text-xs px-2 py-1 rounded-full bg-[#F6F1FF] text-[#8B5CF6] font-medium">
              +{project.technologies.length - 4} more
            </span>
          )}
        </div>

        {/* Action Link Button */}
        <Link
          to={`/projects/${project.slug}`}
          className="inline-flex items-center justify-between w-full px-4 py-2.5 rounded-2xl bg-[#F6F1FF] text-sm font-semibold text-[#8B5CF6] group-hover:bg-[#8B5CF6] group-hover:text-white transition-all duration-200"
        >
          <span>{project.isUiUxCaseStudy ? 'Explore UI/UX Case Study' : 'View Project Case Study'}</span>
          <ArrowUpRight className="w-4 h-4 transform group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform duration-200" />
        </Link>
      </div>
    </div>
  );
};

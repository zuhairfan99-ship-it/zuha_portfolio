import React from 'react';
import { Certification } from '../types';
import { Award, Calendar, ExternalLink, ShieldCheck, Eye } from 'lucide-react';
import { Badge } from './Badge';

interface CertificateCardProps {
  certificate: Certification;
  onOpenModal: (certificate: Certification) => void;
}

export const CertificateCard: React.FC<CertificateCardProps> = ({ certificate, onOpenModal }) => {
  return (
    <div
      onClick={() => onOpenModal(certificate)}
      className="group cursor-pointer rounded-3xl bg-white border border-[#8B5CF6]/15 p-6 sm:p-8 shadow-xs hover:shadow-xl hover:shadow-[#8B5CF6]/10 hover:-translate-y-1 transition-all duration-300 flex flex-col justify-between"
    >
      <div>
        {/* Top visual banner */}
        <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-[#FAF8FF] via-[#F6F1FF] to-[#EDE9FE] border border-[#8B5CF6]/20 p-6 mb-6">
          <div className="flex items-center justify-between">
            <div className="w-12 h-12 rounded-2xl bg-white text-[#8B5CF6] flex items-center justify-center shadow-xs">
              <Award className="w-6 h-6" />
            </div>
            <div className="flex items-center gap-1.5 text-xs text-emerald-700 bg-white/80 px-3 py-1 rounded-full border border-emerald-200 shadow-2xs">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Verified Course</span>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-[#8B5CF6]/10">
            <span className="text-xs font-semibold text-[#8B5CF6] uppercase tracking-wider block">
              {certificate.issuer}
            </span>
            <p className="text-sm font-medium text-[#1F1B2D] mt-0.5 line-clamp-1">
              {certificate.title}
            </p>
          </div>

          {/* Hover overlay hint */}
          <div className="absolute inset-0 bg-[#8B5CF6]/10 backdrop-blur-[1px] opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex items-center justify-center">
            <span className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-white text-xs font-semibold text-[#8B5CF6] shadow-md">
              <Eye className="w-3.5 h-3.5" /> Click to View Certificate
            </span>
          </div>
        </div>

        {/* Title & Metadata */}
        <div className="flex items-center justify-between gap-2 mb-2">
          <Badge variant="lavender" size="sm">
            {certificate.issuer}
          </Badge>
          <span className="flex items-center gap-1 text-xs text-[#6B6478]">
            <Calendar className="w-3.5 h-3.5 text-[#8B5CF6]" />
            {certificate.date}
          </span>
        </div>

        <h3 className="text-xl font-bold tracking-tight text-[#1F1B2D] group-hover:text-[#8B5CF6] transition-colors mb-2">
          {certificate.title}
        </h3>

        {certificate.roleOrSpecialization && (
          <p className="text-xs text-[#8B5CF6] font-medium mb-3">
            {certificate.roleOrSpecialization}
          </p>
        )}

        <p className="text-sm text-[#6B6478] leading-relaxed mb-6">
          {certificate.description}
        </p>

        {/* Skills learned */}
        <div className="space-y-2 mb-6">
          <span className="text-xs font-semibold uppercase tracking-wider text-[#1F1B2D] block">
            Skills Learned:
          </span>
          <div className="flex flex-wrap gap-1.5">
            {certificate.skillsLearned.map((skill) => (
              <span
                key={skill}
                className="text-xs px-2.5 py-1 rounded-full bg-[#FAF8FF] text-[#1F1B2D] border border-[#8B5CF6]/15 font-medium"
              >
                {skill}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Footer Action */}
      <div className="pt-4 border-t border-[#8B5CF6]/10 flex items-center justify-between text-xs text-[#8B5CF6] font-semibold">
        <span className="group-hover:underline">Open Credential Lightbox</span>
        <ExternalLink className="w-4 h-4" />
      </div>
    </div>
  );
};

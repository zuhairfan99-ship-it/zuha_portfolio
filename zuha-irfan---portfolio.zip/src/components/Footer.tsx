import React from 'react';
import { Link, useRouter } from '../context/RouterContext';
import { profileData } from '../data/profile';
import { ArrowUpRight, Github, Linkedin, Mail, Heart } from 'lucide-react';

export const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();
  const { navigate } = useRouter();

  return (
    <footer id="main-footer" className="border-t border-[#8B5CF6]/15 bg-[#FAF8FF] mt-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-12 items-start">
          {/* Brand & Tagline */}
          <div className="md:col-span-6 space-y-4">
            <Link to="/" className="inline-block">
              <span className="text-2xl font-bold tracking-tight text-[#1F1B2D]">
                Zuha<span className="text-[#8B5CF6]">.</span>
              </span>
            </Link>
            <p className="text-base text-[#6B6478] max-w-md leading-relaxed">
              Designing thoughtful digital experiences through design, code, and intelligent technology.
            </p>
            <div className="flex items-center gap-3 pt-2">
              {profileData.contact.socials.map((social) => (
                <a
                  key={social.platform}
                  href={social.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={social.platform}
                  className="w-10 h-10 rounded-full bg-white border border-[#8B5CF6]/20 flex items-center justify-center text-[#1F1B2D] hover:text-[#8B5CF6] hover:border-[#8B5CF6]/40 hover:bg-[#F6F1FF] transition-all duration-200 shadow-2xs"
                >
                  {social.platform === 'GitHub' ? (
                    <Github className="w-4 h-4" />
                  ) : social.platform === 'LinkedIn' ? (
                    <Linkedin className="w-4 h-4" />
                  ) : (
                    <ArrowUpRight className="w-4 h-4" />
                  )}
                </a>
              ))}
              <button
                onClick={() => navigate('/contact')}
                aria-label="Send email"
                className="w-10 h-10 rounded-full bg-white border border-[#8B5CF6]/20 flex items-center justify-center text-[#1F1B2D] hover:text-[#8B5CF6] hover:border-[#8B5CF6]/40 hover:bg-[#F6F1FF] transition-all duration-200 shadow-2xs cursor-pointer"
              >
                <Mail className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Quick Navigation */}
          <div className="md:col-span-3 space-y-3">
            <h4 className="text-xs font-semibold tracking-wider text-[#1F1B2D] uppercase">
              Navigation
            </h4>
            <ul className="space-y-2 text-sm">
              <li>
                <Link to="/" className="text-[#6B6478] hover:text-[#8B5CF6] transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/about" className="text-[#6B6478] hover:text-[#8B5CF6] transition-colors">
                  About
                </Link>
              </li>
              <li>
                <Link to="/projects" className="text-[#6B6478] hover:text-[#8B5CF6] transition-colors">
                  Selected Projects
                </Link>
              </li>
              <li>
                <Link to="/experience" className="text-[#6B6478] hover:text-[#8B5CF6] transition-colors">
                  Experience & Internships
                </Link>
              </li>
              <li>
                <Link to="/skills" className="text-[#6B6478] hover:text-[#8B5CF6] transition-colors">
                  Skills & Expertise
                </Link>
              </li>
              <li>
                <Link to="/certifications" className="text-[#6B6478] hover:text-[#8B5CF6] transition-colors">
                  Certifications
                </Link>
              </li>
              <li>
                <Link to="/resume" className="text-[#6B6478] hover:text-[#8B5CF6] transition-colors">
                  Resume / CV
                </Link>
              </li>
              <li>
                <Link to="/contact" className="text-[#6B6478] hover:text-[#8B5CF6] transition-colors">
                  Contact
                </Link>
              </li>
            </ul>
          </div>

          {/* Focus Disciplines */}
          <div className="md:col-span-3 space-y-3">
            <h4 className="text-xs font-semibold tracking-wider text-[#1F1B2D] uppercase">
              Core Disciplines
            </h4>
            <ul className="space-y-2 text-sm text-[#6B6478]">
              <li className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-[#8B5CF6]" />
                UI/UX & Accessibility
              </li>
              <li className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-[#60A5FA]" />
                Full-Stack Web Development
              </li>
              <li className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-[#A78BFA]" />
                Machine Learning & NLP (PyTorch)
              </li>
              <li className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-[#C4B5FD]" />
                AI Automation Workflows
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-12 pt-8 border-t border-[#8B5CF6]/10 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#6B6478]">
          <p>© {currentYear} Zuha Irfan. All rights reserved.</p>
          <p className="flex items-center gap-1.5">
            Designed with <Heart className="w-3.5 h-3.5 text-[#8B5CF6] fill-[#8B5CF6]" /> and engineered in software.
          </p>
        </div>
      </div>
    </footer>
  );
};

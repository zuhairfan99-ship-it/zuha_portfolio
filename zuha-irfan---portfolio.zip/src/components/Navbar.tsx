import React, { useState, useEffect } from 'react';
import { useRouter, Link } from '../context/RouterContext';
import { Menu, X, ArrowUpRight, FileText } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

const navItems = [
  { label: 'Home', path: '/' },
  { label: 'About', path: '/about' },
  { label: 'Experience', path: '/experience' },
  { label: 'Projects', path: '/projects' },
  { label: 'Skills', path: '/skills' },
  { label: 'Certifications', path: '/certifications' },
  { label: 'Contact', path: '/contact' },
];

export const Navbar: React.FC = () => {
  const { currentPath, navigate } = useRouter();
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close mobile menu on route change
  useEffect(() => {
    setMobileMenuOpen(false);
  }, [currentPath]);

  // Lock body scroll when mobile menu is open
  useEffect(() => {
    if (mobileMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [mobileMenuOpen]);

  const isActive = (path: string) => {
    if (path === '/') {
      return currentPath === '/';
    }
    return currentPath.startsWith(path);
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-[#FAF8FF]/85 backdrop-blur-md shadow-xs border-b border-[#8B5CF6]/10 py-3'
          : 'bg-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Logo / Wordmark */}
          <Link
            to="/"
            className="group flex items-center gap-2 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#8B5CF6] rounded-lg p-1"
          >
            <span className="text-2xl font-bold tracking-tight text-[#1F1B2D] transition-colors group-hover:text-[#8B5CF6]">
              Zuha<span className="text-[#8B5CF6]">.</span>
            </span>
          </Link>

          {/* Desktop Navigation Links */}
          <nav
            id="desktop-navigation"
            aria-label="Main Navigation"
            className="hidden lg:flex items-center gap-1 bg-[#FFFFFF]/70 backdrop-blur-md px-3 py-1.5 rounded-full border border-[#8B5CF6]/15 shadow-xs"
          >
            {navItems.map((item) => {
              const active = isActive(item.path);
              return (
                <Link
                  key={item.path}
                  id={`nav-link-${item.label.toLowerCase()}`}
                  to={item.path}
                  className={`relative px-3.5 py-1.5 rounded-full text-sm font-medium transition-all duration-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#8B5CF6] ${
                    active
                      ? 'text-[#8B5CF6] font-semibold'
                      : 'text-[#6B6478] hover:text-[#1F1B2D] hover:bg-[#F6F1FF]'
                  }`}
                >
                  {item.label}
                  {active && (
                    <motion.div
                      layoutId="activeNavPill"
                      className="absolute inset-0 bg-[#EDE9FE] rounded-full -z-10"
                      transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                    />
                  )}
                </Link>
              );
            })}
          </nav>

          {/* Right side CTA Button */}
          <div className="hidden lg:flex items-center gap-3">
            <button
              id="nav-view-resume-btn"
              onClick={() => navigate('/resume')}
              className="group inline-flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-medium text-white bg-gradient-to-r from-[#8B5CF6] to-[#7C3AED] hover:from-[#7C3AED] hover:to-[#6D28D9] shadow-sm hover:shadow-md hover:shadow-[#8B5CF6]/20 transition-all duration-200 cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-[#8B5CF6] focus-visible:ring-offset-2"
            >
              <FileText className="w-4 h-4 transition-transform group-hover:scale-110" />
              <span>View Resume</span>
              <ArrowUpRight className="w-3.5 h-3.5 transition-transform duration-200 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </button>
          </div>

          {/* Mobile Menu Button */}
          <div className="flex items-center gap-2 lg:hidden">
            <button
              id="mobile-view-resume-btn"
              onClick={() => navigate('/resume')}
              className="p-2 rounded-full text-[#8B5CF6] bg-[#EDE9FE] hover:bg-[#DDD6FE] transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[#8B5CF6]"
              aria-label="View Resume"
            >
              <FileText className="w-4 h-4" />
            </button>
            <button
              id="mobile-menu-toggle-btn"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2.5 rounded-2xl bg-white border border-[#8B5CF6]/20 text-[#1F1B2D] hover:bg-[#F6F1FF] transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[#8B5CF6]"
              aria-label={mobileMenuOpen ? 'Close menu' : 'Open menu'}
              aria-expanded={mobileMenuOpen}
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Overlay */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
            className="lg:hidden fixed inset-x-4 top-20 z-50 bg-white/95 backdrop-blur-xl border border-[#8B5CF6]/20 rounded-3xl p-6 shadow-xl shadow-purple-900/5 max-h-[calc(100vh-6rem)] overflow-y-auto"
          >
            <div className="flex flex-col gap-1">
              {navItems.map((item) => {
                const active = isActive(item.path);
                return (
                  <Link
                    key={item.path}
                    to={item.path}
                    onClick={() => setMobileMenuOpen(false)}
                    className={`flex items-center justify-between px-4 py-3 rounded-2xl text-base font-medium transition-all ${
                      active
                        ? 'bg-[#EDE9FE] text-[#8B5CF6] font-semibold'
                        : 'text-[#1F1B2D] hover:bg-[#FAF8FF]'
                    }`}
                  >
                    <span>{item.label}</span>
                    {active && <span className="w-2 h-2 rounded-full bg-[#8B5CF6]" />}
                  </Link>
                );
              })}
            </div>

            <div className="mt-6 pt-6 border-t border-[#8B5CF6]/10 flex flex-col gap-3">
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  navigate('/resume');
                }}
                className="w-full flex items-center justify-center gap-2 px-5 py-3 rounded-2xl text-base font-medium text-white bg-gradient-to-r from-[#8B5CF6] to-[#7C3AED] shadow-sm active:scale-[0.98] transition-transform"
              >
                <FileText className="w-4 h-4" />
                <span>View Full Resume</span>
                <ArrowUpRight className="w-4 h-4" />
              </button>
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  navigate('/contact');
                }}
                className="w-full flex items-center justify-center gap-2 px-5 py-3 rounded-2xl text-base font-medium text-[#1F1B2D] bg-[#F6F1FF] hover:bg-[#EDE9FE] transition-colors"
              >
                <span>Get in Touch</span>
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
};

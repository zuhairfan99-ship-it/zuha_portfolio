import React from 'react';
import { SkillCategory } from '../types';
import { Palette, Code2, Cpu, Database, Sparkles } from 'lucide-react';

interface SkillCardProps {
  category: SkillCategory;
}

export const SkillCard: React.FC<SkillCardProps> = ({ category }) => {
  const getIcon = (name: string) => {
    switch (name) {
      case 'Palette':
        return <Palette className="w-6 h-6 text-[#8B5CF6]" />;
      case 'Code2':
        return <Code2 className="w-6 h-6 text-[#60A5FA]" />;
      case 'Cpu':
        return <Cpu className="w-6 h-6 text-[#A78BFA]" />;
      case 'Database':
        return <Database className="w-6 h-6 text-[#7C3AED]" />;
      default:
        return <Sparkles className="w-6 h-6 text-[#8B5CF6]" />;
    }
  };

  return (
    <div className="group rounded-3xl bg-white border border-[#8B5CF6]/15 p-6 sm:p-8 shadow-xs hover:shadow-xl hover:shadow-[#8B5CF6]/10 hover:-translate-y-1 transition-all duration-300 flex flex-col justify-between">
      <div>
        {/* Icon & Title Header */}
        <div className="flex items-center gap-4 mb-4">
          <div className="w-12 h-12 rounded-2xl bg-[#F6F1FF] border border-[#8B5CF6]/20 flex items-center justify-center group-hover:scale-105 group-hover:rotate-3 transition-transform duration-300 shadow-2xs">
            {getIcon(category.iconName)}
          </div>
          <div>
            <h3 className="text-xl font-bold tracking-tight text-[#1F1B2D]">
              {category.title}
            </h3>
            <span className="text-xs text-[#8B5CF6] font-medium">
              {category.skills.length} competencies
            </span>
          </div>
        </div>

        {/* Short description */}
        <p className="text-sm text-[#6B6478] leading-relaxed mb-6">
          {category.description}
        </p>

        {/* Categorized Pills */}
        <div className="flex flex-wrap gap-2">
          {category.skills.map((skill) => (
            <span
              key={skill}
              className="text-xs sm:text-sm px-3 py-1.5 rounded-full bg-[#FAF8FF] text-[#1F1B2D] border border-[#8B5CF6]/15 hover:border-[#8B5CF6]/40 hover:bg-[#EDE9FE] hover:text-[#7C3AED] transition-all duration-150 font-medium cursor-default shadow-2xs"
            >
              {skill}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
};

import React from 'react';
import { motion, useReducedMotion } from 'motion/react';

interface PageTransitionProps {
  children: React.ReactNode;
  className?: string;
  pageKey?: string;
}

export const PageTransition: React.FC<PageTransitionProps> = ({ children, className = '', pageKey }) => {
  const shouldReduceMotion = useReducedMotion();

  return (
    <motion.div
      key={pageKey}
      initial={{ opacity: 0, y: shouldReduceMotion ? 0 : 14 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: shouldReduceMotion ? 0 : -10 }}
      transition={{
        duration: shouldReduceMotion ? 0 : 0.35,
        ease: 'easeOut',
      }}
      className={`min-h-[calc(100vh-18rem)] ${className}`}
    >
      {children}
    </motion.div>
  );
};

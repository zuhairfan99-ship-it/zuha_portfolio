import React, { useState } from 'react';
import { Send, CheckCircle2, AlertCircle, Loader2, Copy, Check } from 'lucide-react';
import { profileData } from '../data/profile';

interface FormData {
  name: string;
  email: string;
  subject: string;
  message: string;
}

interface FormErrors {
  name?: string;
  email?: string;
  subject?: string;
  message?: string;
}

export const ContactForm: React.FC = () => {
  const [formData, setFormData] = useState<FormData>({
    name: '',
    email: '',
    subject: '',
    message: '',
  });

  const [errors, setErrors] = useState<FormErrors>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [copiedEmail, setCopiedEmail] = useState(false);

  const validate = (): boolean => {
    const errs: FormErrors = {};

    if (!formData.name.trim()) {
      errs.name = 'Please provide your name.';
    }

    if (!formData.email.trim()) {
      errs.email = 'Please provide your email address.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      errs.email = 'Please enter a valid email address.';
    }

    if (!formData.subject.trim()) {
      errs.subject = 'Please specify a subject.';
    }

    if (!formData.message.trim()) {
      errs.message = 'Please include a message.';
    } else if (formData.message.trim().length < 10) {
      errs.message = 'Please provide a message with at least 10 characters.';
    }

    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validate()) return;

    setIsSubmitting(true);

    // Simulate network submission to simulate integration readiness
    await new Promise((resolve) => setTimeout(resolve, 800));

    setIsSubmitting(false);
    setIsSubmitted(true);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(profileData.contact.email);
    setCopiedEmail(true);
    setTimeout(() => setCopiedEmail(false), 2500);
  };

  return (
    <div className="bg-white rounded-3xl p-6 sm:p-10 border border-[#8B5CF6]/15 shadow-sm">
      {isSubmitted ? (
        <div className="text-center py-8 space-y-4">
          <div className="w-16 h-16 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-600 flex items-center justify-center mx-auto">
            <CheckCircle2 className="w-8 h-8" />
          </div>
          <h3 className="text-2xl font-bold tracking-tight text-[#1F1B2D]">
            Message Received!
          </h3>
          <p className="text-sm sm:text-base text-[#6B6478] max-w-md mx-auto leading-relaxed">
            Thank you for reaching out, <span className="font-semibold text-[#1F1B2D]">{formData.name}</span>. 
            This form is prepared with clean client-side validation for backend integration (e.g., Formspree or custom API).
          </p>
          <div className="p-4 rounded-2xl bg-[#FAF8FF] border border-[#8B5CF6]/20 max-w-md mx-auto text-left text-xs text-[#6B6478] space-y-2">
            <p className="font-medium text-[#1F1B2D]">Need an immediate reply?</p>
            <p>You can also copy Zuha&apos;s direct email or send via your default email client:</p>
            <div className="flex items-center justify-between bg-white p-2 rounded-xl border border-[#8B5CF6]/15 mt-2">
              <span className="font-mono text-xs text-[#8B5CF6] truncate mr-2">
                {profileData.contact.email}
              </span>
              <button
                onClick={copyToClipboard}
                className="inline-flex items-center gap-1 text-xs px-2.5 py-1 rounded-lg bg-[#EDE9FE] text-[#7C3AED] hover:bg-[#DDD6FE] transition-colors shrink-0 cursor-pointer"
              >
                {copiedEmail ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy</span>
                  </>
                )}
              </button>
            </div>
          </div>
          <button
            onClick={() => {
              setIsSubmitted(false);
              setFormData({ name: '', email: '', subject: '', message: '' });
            }}
            className="mt-4 px-6 py-2.5 rounded-full text-sm font-medium text-[#8B5CF6] hover:bg-[#FAF8FF] border border-[#8B5CF6]/30 transition-colors"
          >
            Send Another Message
          </button>
        </div>
      ) : (
        <form id="contact-form" onSubmit={handleSubmit} noValidate className="space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            {/* Name */}
            <div className="space-y-1.5">
              <label htmlFor="name" className="block text-xs font-semibold uppercase tracking-wider text-[#1F1B2D]">
                Your Name <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                id="name"
                value={formData.name}
                onChange={(e) => {
                  setFormData({ ...formData, name: e.target.value });
                  if (errors.name) setErrors({ ...errors, name: undefined });
                }}
                placeholder="e.g. Sarah Khan"
                className={`w-full px-4 py-3 rounded-2xl bg-[#FAF8FF] border text-sm text-[#1F1B2D] placeholder-[#6B6478]/50 focus:outline-none focus:ring-2 focus:ring-[#8B5CF6] transition-all ${
                  errors.name ? 'border-red-400 bg-red-50/30' : 'border-[#8B5CF6]/20'
                }`}
              />
              {errors.name && (
                <p className="text-xs text-red-500 flex items-center gap-1 mt-1">
                  <AlertCircle className="w-3.5 h-3.5" /> {errors.name}
                </p>
              )}
            </div>

            {/* Email */}
            <div className="space-y-1.5">
              <label htmlFor="email" className="block text-xs font-semibold uppercase tracking-wider text-[#1F1B2D]">
                Your Email <span className="text-red-500">*</span>
              </label>
              <input
                type="email"
                id="email"
                value={formData.email}
                onChange={(e) => {
                  setFormData({ ...formData, email: e.target.value });
                  if (errors.email) setErrors({ ...errors, email: undefined });
                }}
                placeholder="e.g. sarah@company.com"
                className={`w-full px-4 py-3 rounded-2xl bg-[#FAF8FF] border text-sm text-[#1F1B2D] placeholder-[#6B6478]/50 focus:outline-none focus:ring-2 focus:ring-[#8B5CF6] transition-all ${
                  errors.email ? 'border-red-400 bg-red-50/30' : 'border-[#8B5CF6]/20'
                }`}
              />
              {errors.email && (
                <p className="text-xs text-red-500 flex items-center gap-1 mt-1">
                  <AlertCircle className="w-3.5 h-3.5" /> {errors.email}
                </p>
              )}
            </div>
          </div>

          {/* Subject */}
          <div className="space-y-1.5">
            <label htmlFor="subject" className="block text-xs font-semibold uppercase tracking-wider text-[#1F1B2D]">
              Subject / Inquiry Type <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              id="subject"
              value={formData.subject}
              onChange={(e) => {
                setFormData({ ...formData, subject: e.target.value });
                if (errors.subject) setErrors({ ...errors, subject: undefined });
              }}
              placeholder="e.g. Software Engineering Internship Opportunity"
              className={`w-full px-4 py-3 rounded-2xl bg-[#FAF8FF] border text-sm text-[#1F1B2D] placeholder-[#6B6478]/50 focus:outline-none focus:ring-2 focus:ring-[#8B5CF6] transition-all ${
                errors.subject ? 'border-red-400 bg-red-50/30' : 'border-[#8B5CF6]/20'
              }`}
            />
            {errors.subject && (
              <p className="text-xs text-red-500 flex items-center gap-1 mt-1">
                <AlertCircle className="w-3.5 h-3.5" /> {errors.subject}
              </p>
            )}
          </div>

          {/* Message */}
          <div className="space-y-1.5">
            <label htmlFor="message" className="block text-xs font-semibold uppercase tracking-wider text-[#1F1B2D]">
              Your Message <span className="text-red-500">*</span>
            </label>
            <textarea
              id="message"
              rows={5}
              value={formData.message}
              onChange={(e) => {
                setFormData({ ...formData, message: e.target.value });
                if (errors.message) setErrors({ ...errors, message: undefined });
              }}
              placeholder="Share details about the role, project collaboration, or question..."
              className={`w-full px-4 py-3 rounded-2xl bg-[#FAF8FF] border text-sm text-[#1F1B2D] placeholder-[#6B6478]/50 focus:outline-none focus:ring-2 focus:ring-[#8B5CF6] transition-all resize-y ${
                errors.message ? 'border-red-400 bg-red-50/30' : 'border-[#8B5CF6]/20'
              }`}
            />
            {errors.message && (
              <p className="text-xs text-red-500 flex items-center gap-1 mt-1">
                <AlertCircle className="w-3.5 h-3.5" /> {errors.message}
              </p>
            )}
          </div>

          {/* Submit Button */}
          <button
            id="contact-submit-btn"
            type="submit"
            disabled={isSubmitting}
            className="w-full inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-2xl text-sm font-semibold text-white bg-gradient-to-r from-[#8B5CF6] to-[#7C3AED] hover:from-[#7C3AED] hover:to-[#6D28D9] shadow-sm hover:shadow-md hover:shadow-[#8B5CF6]/20 active:scale-[0.99] transition-all disabled:opacity-60 cursor-pointer"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Sending Message...</span>
              </>
            ) : (
              <>
                <Send className="w-4 h-4" />
                <span>Send Message</span>
              </>
            )}
          </button>

          <p className="text-center text-[11px] text-[#6B6478]">
            Form handles validation client-side. Messages are safely verified before submission.
          </p>
        </form>
      )}
    </div>
  );
};

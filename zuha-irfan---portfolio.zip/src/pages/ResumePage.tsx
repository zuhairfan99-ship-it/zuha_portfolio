import React, { useState } from 'react';
import { profileData } from '../data/profile';
import { experienceData } from '../data/experience';
import { skillsData } from '../data/skills';
import { Badge } from '../components/Badge';
import { 
  FileText, 
  Download, 
  Eye, 
  CheckCircle2, 
  ExternalLink, 
  GraduationCap, 
  Briefcase, 
  Mail, 
  MapPin, 
  Linkedin, 
  Github,
  Printer
} from 'lucide-react';

export const ResumePage: React.FC = () => {
  const [selectedResumeId, setSelectedResumeId] = useState<string>(profileData.resumes[0].id);

  const currentResume = profileData.resumes.find((r) => r.id === selectedResumeId) || profileData.resumes[0];

  const handleDownload = (fileName: string) => {
    // Graceful download trigger with notification
    alert(`Downloading ${fileName}...\n(Note: Replace downloadUrl with your actual hosted PDF in data/profile.ts when ready!)`);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12 sm:space-y-16">
      {/* 1. HERO SECTION */}
      <section className="space-y-6">
        <Badge variant="lavender" size="md" icon={<FileText className="w-3.5 h-3.5 text-[#8B5CF6]" />}>
          Curriculum Vitae
        </Badge>
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6">
          <div className="space-y-4 max-w-3xl">
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-[#1F1B2D] leading-[1.15]">
              Resume &{' '}
              <span className="bg-gradient-to-r from-[#8B5CF6] via-[#7C3AED] to-[#60A5FA] bg-clip-text text-transparent">
                Credentials.
              </span>
            </h1>
            <p className="text-lg sm:text-xl text-[#6B6478] leading-relaxed">
              Targeted resume versions tailored specifically for AI/ML engineering, Full-Stack development, and UI/UX product design opportunities.
            </p>
          </div>

          {/* Quick Print action */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-semibold text-[#1F1B2D] bg-white border border-[#8B5CF6]/20 hover:bg-[#F6F1FF] transition-colors cursor-pointer shadow-2xs"
            >
              <Printer className="w-4 h-4 text-[#8B5CF6]" />
              <span>Print / PDF View</span>
            </button>
          </div>
        </div>
      </section>

      {/* 2. RESUME VERSION SELECTOR TABS */}
      <section className="space-y-6">
        <div className="flex flex-wrap items-center gap-3 border-b border-[#8B5CF6]/15 pb-6">
          {profileData.resumes.map((resume) => {
            const isSelected = selectedResumeId === resume.id;
            return (
              <button
                key={resume.id}
                onClick={() => setSelectedResumeId(resume.id)}
                className={`relative px-5 py-3 rounded-2xl text-sm font-semibold transition-all duration-200 cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-[#8B5CF6] ${
                  isSelected
                    ? 'text-white bg-[#8B5CF6] shadow-md shadow-[#8B5CF6]/25'
                    : 'text-[#6B6478] bg-white border border-[#8B5CF6]/15 hover:bg-[#F6F1FF] hover:text-[#1F1B2D]'
                }`}
              >
                <span>{resume.title}</span>
              </button>
            );
          })}
        </div>

        {/* Selected Resume Highlights Header Card */}
        <div className="rounded-3xl bg-gradient-to-r from-white via-[#FAF8FF] to-[#EDE9FE] border border-[#8B5CF6]/20 p-6 sm:p-8 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <Badge variant="lavender" size="sm">{currentResume.category}</Badge>
              <span className="text-xs text-[#6B6478]">Updated: {currentResume.updatedDate} • {currentResume.fileSize}</span>
            </div>
            <h2 className="text-2xl font-bold text-[#1F1B2D]">{currentResume.title}</h2>
            <p className="text-sm text-[#6B6478] max-w-2xl">{currentResume.summary}</p>
          </div>

          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <button
              onClick={() => handleDownload(currentResume.fileName)}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-full text-sm font-semibold text-white bg-gradient-to-r from-[#8B5CF6] to-[#7C3AED] hover:from-[#7C3AED] hover:to-[#6D28D9] shadow-sm hover:shadow-md transition-all cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Download Resume</span>
            </button>
          </div>
        </div>
      </section>

      {/* 3. INTERACTIVE SCANNABLE RESUME DOCUMENT (Accessible & Responsive) */}
      <section className="max-w-4xl mx-auto bg-white rounded-3xl border border-[#8B5CF6]/20 p-8 sm:p-14 shadow-sm space-y-12">
        {/* Document Header */}
        <div className="border-b border-[#8B5CF6]/15 pb-8 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-3xl sm:text-4xl font-extrabold text-[#1F1B2D] tracking-tight">
                Zuha Irfan
              </h2>
              <p className="text-base text-[#8B5CF6] font-semibold mt-1">
                Software Engineering Student &bull; UI/UX Designer &bull; AI/ML Practitioner
              </p>
            </div>
            <div className="text-xs sm:text-right space-y-1 text-[#6B6478]">
              <p className="flex sm:justify-end items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-[#8B5CF6]" />
                {profileData.contact.location}
              </p>
              <p className="flex sm:justify-end items-center gap-1.5">
                <Mail className="w-3.5 h-3.5 text-[#8B5CF6]" />
                {profileData.contact.email}
              </p>
            </div>
          </div>

          <p className="text-sm text-[#6B6478] leading-relaxed pt-2">
            {profileData.aboutIntro}
          </p>
        </div>

        {/* Education Block */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 text-[#8B5CF6]">
            <GraduationCap className="w-5 h-5" />
            <h3 className="text-xs font-bold uppercase tracking-wider text-[#1F1B2D]">
              Education
            </h3>
          </div>

          <div className="space-y-4">
            {profileData.education.map((edu, idx) => (
              <div key={idx} className="flex flex-col sm:flex-row sm:items-start justify-between gap-1">
                <div>
                  <h4 className="text-base font-bold text-[#1F1B2D]">{edu.degree}</h4>
                  <p className="text-sm text-[#8B5CF6] font-medium">{edu.institution} &bull; {edu.location}</p>
                  {edu.details && (
                    <ul className="mt-2 space-y-1 text-xs text-[#6B6478]">
                      {edu.details.map((d, i) => (
                        <li key={i} className="flex items-start gap-2">
                          <span className="w-1 h-1 rounded-full bg-[#8B5CF6] mt-1.5 shrink-0" />
                          <span>{d}</span>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
                <span className="text-xs font-mono text-[#6B6478] shrink-0 mt-1 sm:mt-0">
                  {edu.dates}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Experience Block */}
        <div className="space-y-6">
          <div className="flex items-center gap-2 text-[#8B5CF6]">
            <Briefcase className="w-5 h-5" />
            <h3 className="text-xs font-bold uppercase tracking-wider text-[#1F1B2D]">
              Internship Experience
            </h3>
          </div>

          <div className="space-y-8">
            {experienceData.map((exp) => (
              <div key={exp.id} className="space-y-2">
                <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-1">
                  <div>
                    <h4 className="text-base font-bold text-[#1F1B2D]">{exp.role}</h4>
                    <p className="text-xs font-semibold text-[#8B5CF6]">
                      {exp.company} &bull; {exp.location} {exp.isRemote && '(Remote)'}
                    </p>
                  </div>
                  <span className="text-xs font-mono text-[#6B6478] shrink-0">
                    {exp.dates}
                  </span>
                </div>

                <ul className="space-y-1.5 text-xs text-[#6B6478] pt-1">
                  {exp.responsibilities.map((r, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <span className="w-1 h-1 rounded-full bg-[#8B5CF6] mt-1.5 shrink-0" />
                      <span>{r}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        {/* Skills Block */}
        <div className="space-y-4 pt-4 border-t border-[#8B5CF6]/15">
          <h3 className="text-xs font-bold uppercase tracking-wider text-[#1F1B2D]">
            Technical & Methodological Competencies
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            {skillsData.map((category) => (
              <div key={category.title} className="p-3.5 rounded-2xl bg-[#FAF8FF] border border-[#8B5CF6]/15 space-y-1.5">
                <span className="font-bold text-[#8B5CF6] block">{category.title}</span>
                <p className="text-[#6B6478] leading-relaxed">
                  {category.skills.join(', ')}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

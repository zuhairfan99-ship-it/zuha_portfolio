import React from 'react';
import { experienceData } from '../data/experience';
import { ExperienceCard } from '../components/ExperienceCard';
import { SectionHeading } from '../components/SectionHeading';
import { Badge } from '../components/Badge';
import { useRouter } from '../context/RouterContext';
import { Briefcase, ArrowRight, Download } from 'lucide-react';

export const ExperiencePage: React.FC = () => {
  const { navigate } = useRouter();

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16 sm:space-y-24">
      {/* 1. HERO SECTION */}
      <section className="space-y-6">
        <Badge variant="lavender" size="md">
          Work History & Internships
        </Badge>
        <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-[#1F1B2D] leading-[1.15] max-w-4xl">
          Practical Experience Across{' '}
          <span className="bg-gradient-to-r from-[#8B5CF6] via-[#7C3AED] to-[#60A5FA] bg-clip-text text-transparent">
            Design & Technology.
          </span>
        </h1>
        <p className="text-lg sm:text-xl text-[#6B6478] leading-relaxed max-w-3xl">
          A progressive timeline of professional internship roles spanning user experience research, machine learning experimentation in PyTorch, full-stack API integration, and automated workflow pipelines.
        </p>

        {/* Quick action strip */}
        <div className="flex flex-wrap items-center gap-3 pt-2">
          <button
            onClick={() => navigate('/resume')}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-semibold text-white bg-[#8B5CF6] hover:bg-[#7C3AED] shadow-sm transition-colors cursor-pointer"
          >
            <Briefcase className="w-4 h-4" />
            <span>View Resume Formats</span>
          </button>
          <button
            onClick={() => navigate('/contact')}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-semibold text-[#1F1B2D] bg-white border border-[#8B5CF6]/20 hover:bg-[#F6F1FF] transition-colors cursor-pointer shadow-2xs"
          >
            <span>Inquire for Roles</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </section>

      {/* 2. TIMELINE SECTION */}
      <section className="max-w-4xl mx-auto pt-4">
        <div className="relative">
          {experienceData.map((item, idx) => (
            <ExperienceCard
              key={item.id}
              experience={item}
              isLast={idx === experienceData.length - 1}
            />
          ))}
        </div>
      </section>

      {/* 3. FUTURE OPPORTUNITIES NOTE */}
      <section className="max-w-4xl mx-auto rounded-3xl bg-white border border-[#8B5CF6]/15 p-8 sm:p-10 shadow-xs text-center space-y-4">
        <Badge variant="lavender" size="sm">
          Open to New Opportunities
        </Badge>
        <h3 className="text-2xl font-bold tracking-tight text-[#1F1B2D]">
          Looking for a dedicated Software Engineering intern?
        </h3>
        <p className="text-sm sm:text-base text-[#6B6478] max-w-2xl mx-auto leading-relaxed">
          I am actively preparing for summer and semester internships in UI/UX Design, Front-End / Full-Stack Engineering, and AI/ML development.
        </p>
        <div className="pt-2">
          <button
            onClick={() => navigate('/contact')}
            className="inline-flex items-center gap-2 px-6 py-3 rounded-full text-sm font-semibold text-white bg-gradient-to-r from-[#8B5CF6] to-[#7C3AED] hover:from-[#7C3AED] hover:to-[#6D28D9] shadow-sm transition-all cursor-pointer"
          >
            <span>Let&apos;s Connect</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </section>
    </div>
  );
};

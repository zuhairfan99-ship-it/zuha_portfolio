import React from 'react';
import { skillsData } from '../data/skills';
import { SkillCard } from '../components/SkillCard';
import { SectionHeading } from '../components/SectionHeading';
import { Badge } from '../components/Badge';
import { useRouter } from '../context/RouterContext';
import { Sparkles, ArrowRight, ShieldCheck } from 'lucide-react';

export const SkillsPage: React.FC = () => {
  const { navigate } = useRouter();

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16 sm:space-y-24">
      {/* 1. HERO SECTION */}
      <section className="space-y-6">
        <Badge variant="lavender" size="md" icon={<Sparkles className="w-3.5 h-3.5 text-[#8B5CF6]" />}>
          Technical & Design Capabilities
        </Badge>
        <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-[#1F1B2D] leading-[1.15] max-w-4xl">
          Skills &{' '}
          <span className="bg-gradient-to-r from-[#8B5CF6] via-[#7C3AED] to-[#60A5FA] bg-clip-text text-transparent">
            Expertise.
          </span>
        </h1>
        <p className="text-lg sm:text-xl text-[#6B6478] leading-relaxed max-w-3xl">
          A structured inventory of verified competencies across user experience research, software development, PyTorch machine learning, and workflow automation. Categorized cleanly without arbitrary numeric percentage bars.
        </p>

        <div className="flex items-center gap-2 text-xs text-[#6B6478] pt-1">
          <ShieldCheck className="w-4 h-4 text-[#8B5CF6]" />
          <span>All listed skills represent verified academic coursework, self-directed projects, or internship responsibilities.</span>
        </div>
      </section>

      {/* 2. SKILL CATEGORIES GRID */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {skillsData.map((category) => (
          <SkillCard key={category.title} category={category} />
        ))}
      </section>

      {/* 3. APPROACH & METHODOLOGY HIGHLIGHT */}
      <section className="rounded-3xl bg-white border border-[#8B5CF6]/15 p-8 sm:p-12 shadow-xs space-y-6">
        <div className="max-w-3xl space-y-4">
          <Badge variant="lavender" size="sm">
            Methodological Approach
          </Badge>
          <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-[#1F1B2D]">
            How I Apply These Skills
          </h2>
          <p className="text-sm sm:text-base text-[#6B6478] leading-relaxed">
            I approach technical problems by first understanding the human experience: who needs this system, what friction they encounter, and how clear information hierarchy can alleviate cognitive strain. From there, I bring structured software engineering principles — from Git versioning and relational database hygiene to PyTorch experimental benchmarking — to implement reliable, production-ready solutions.
          </p>
        </div>

        <div className="pt-4 border-t border-[#8B5CF6]/15 flex flex-wrap items-center justify-between gap-4">
          <p className="text-xs text-[#6B6478]">
            Want to see how these competencies translate into live projects?
          </p>
          <button
            onClick={() => navigate('/projects')}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full text-xs sm:text-sm font-semibold text-white bg-[#8B5CF6] hover:bg-[#7C3AED] transition-colors cursor-pointer"
          >
            <span>Explore Project Work</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </section>
    </div>
  );
};

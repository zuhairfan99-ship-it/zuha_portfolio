import React, { useState } from 'react';
import { profileData } from '../data/profile';
import { ContactForm } from '../components/ContactForm';
import { Badge } from '../components/Badge';
import { 
  Mail, 
  MapPin, 
  Calendar, 
  Github, 
  Linkedin, 
  Copy, 
  Check, 
  ArrowUpRight, 
  Sparkles,
  Clock
} from 'lucide-react';

export const ContactPage: React.FC = () => {
  const [copied, setCopied] = useState(false);

  const copyEmail = () => {
    navigator.clipboard.writeText(profileData.contact.email);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16 sm:space-y-24">
      {/* 1. HERO HEADER */}
      <section className="space-y-6">
        <Badge variant="lavender" size="md" icon={<Sparkles className="w-3.5 h-3.5 text-[#8B5CF6]" />}>
          Get In Touch
        </Badge>
        <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-[#1F1B2D] leading-[1.15] max-w-4xl">
          Let&apos;s Create{' '}
          <span className="bg-gradient-to-r from-[#8B5CF6] via-[#7C3AED] to-[#60A5FA] bg-clip-text text-transparent">
            Something Together.
          </span>
        </h1>
        <p className="text-lg sm:text-xl text-[#6B6478] leading-relaxed max-w-3xl">
          Have an internship opening, freelance project inquiry, or questions about my case studies? Drop a message below or connect via email or LinkedIn.
        </p>
      </section>

      {/* 2. TWO-COLUMN CONTACT LAYOUT */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
        {/* Left Column: Contact details & Social links */}
        <div className="lg:col-span-5 space-y-6">
          {/* Email card with quick copy button */}
          <div className="rounded-3xl bg-white border border-[#8B5CF6]/15 p-6 sm:p-8 shadow-xs space-y-4">
            <span className="text-xs font-semibold uppercase tracking-wider text-[#8B5CF6] block">
              Direct Contact
            </span>
            <div>
              <p className="text-xs text-[#6B6478]">Direct Email Address:</p>
              <div className="flex items-center justify-between gap-2 mt-1">
                <span className="text-base sm:text-lg font-bold text-[#1F1B2D] font-mono truncate">
                  {profileData.contact.email}
                </span>
                <button
                  onClick={copyEmail}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#EDE9FE] text-[#7C3AED] hover:bg-[#DDD6FE] transition-colors text-xs font-semibold shrink-0 cursor-pointer"
                  aria-label="Copy email address"
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            <div className="pt-4 border-t border-[#8B5CF6]/10 space-y-3 text-xs text-[#6B6478]">
              <div className="flex items-center gap-2.5">
                <MapPin className="w-4 h-4 text-[#8B5CF6]" />
                <span>{profileData.contact.location}</span>
              </div>
              <div className="flex items-center gap-2.5">
                <Clock className="w-4 h-4 text-[#8B5CF6]" />
                <span>{profileData.contact.availability}</span>
              </div>
            </div>
          </div>

          {/* Social Profiles Card */}
          <div className="rounded-3xl bg-white border border-[#8B5CF6]/15 p-6 sm:p-8 shadow-xs space-y-4">
            <span className="text-xs font-semibold uppercase tracking-wider text-[#8B5CF6] block">
              Professional Profiles
            </span>
            <div className="space-y-3">
              {profileData.contact.socials.map((social) => (
                <a
                  key={social.platform}
                  href={social.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-between p-3.5 rounded-2xl bg-[#FAF8FF] border border-[#8B5CF6]/15 hover:border-[#8B5CF6]/40 hover:bg-[#F6F1FF] transition-all group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-white text-[#8B5CF6] flex items-center justify-center shadow-2xs">
                      {social.platform === 'GitHub' ? (
                        <Github className="w-4 h-4" />
                      ) : (
                        <Linkedin className="w-4 h-4" />
                      )}
                    </div>
                    <div>
                      <p className="text-sm font-bold text-[#1F1B2D] group-hover:text-[#8B5CF6] transition-colors">
                        {social.platform}
                      </p>
                      <p className="text-xs text-[#6B6478]">{social.handle}</p>
                    </div>
                  </div>
                  <ArrowUpRight className="w-4 h-4 text-[#6B6478] group-hover:text-[#8B5CF6] transition-colors" />
                </a>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Interactive Form */}
        <div className="lg:col-span-7">
          <ContactForm />
        </div>
      </section>
    </div>
  );
};

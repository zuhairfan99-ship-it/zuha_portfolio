import React, { useState } from 'react';
import { certificationsData } from '../data/certifications';
import { Certification } from '../types';
import { CertificateCard } from '../components/CertificateCard';
import { CertificateModal } from '../components/CertificateModal';
import { Badge } from '../components/Badge';
import { SectionHeading } from '../components/SectionHeading';
import { Award, ShieldCheck, ExternalLink } from 'lucide-react';

export const CertificationsPage: React.FC = () => {
  const [activeModalCert, setActiveModalCert] = useState<Certification | null>(null);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16 sm:space-y-24">
      {/* 1. HERO SECTION */}
      <section className="space-y-6">
        <Badge variant="lavender" size="md" icon={<Award className="w-3.5 h-3.5 text-[#8B5CF6]" />}>
          Verified Credentials
        </Badge>
        <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-[#1F1B2D] leading-[1.15] max-w-4xl">
          Certifications &{' '}
          <span className="bg-gradient-to-r from-[#8B5CF6] via-[#7C3AED] to-[#60A5FA] bg-clip-text text-transparent">
            Accreditations.
          </span>
        </h1>
        <p className="text-lg sm:text-xl text-[#6B6478] leading-relaxed max-w-3xl">
          Formal training and internship certificates demonstrating specialized immersion in Artificial Intelligence, applied machine learning, and workflow automation.
        </p>

        <div className="flex items-center gap-2 text-xs text-[#6B6478]">
          <ShieldCheck className="w-4 h-4 text-emerald-600" />
          <span>Click any certificate below to launch the accessible inspection lightbox.</span>
        </div>
      </section>

      {/* 2. CERTIFICATIONS GRID */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {certificationsData.map((cert) => (
          <CertificateCard
            key={cert.id}
            certificate={cert}
            onOpenModal={(c) => setActiveModalCert(c)}
          />
        ))}
      </section>

      {/* 3. VERIFICATION FOOTNOTE */}
      <section className="rounded-3xl bg-white border border-[#8B5CF6]/15 p-8 shadow-xs text-center space-y-3 max-w-3xl mx-auto">
        <p className="text-sm text-[#6B6478]">
          All certifications are maintained with verifiable credential identifiers. Additional course certificates and academic transcripts can be provided upon formal employer request.
        </p>
      </section>

      {/* Lightbox Modal */}
      <CertificateModal
        certificate={activeModalCert}
        onClose={() => setActiveModalCert(null)}
      />
    </div>
  );
};

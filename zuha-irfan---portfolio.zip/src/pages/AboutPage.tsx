import React from 'react';
import { profileData } from '../data/profile';
import { SectionHeading } from '../components/SectionHeading';
import { Badge } from '../components/Badge';
import { useRouter } from '../context/RouterContext';
import { 
  GraduationCap, 
  Heart, 
  Lightbulb, 
  Compass, 
  Accessibility, 
  CheckCircle2, 
  ArrowRight,
  Quote,
  Sparkles,
  MapPin,
  Calendar
} from 'lucide-react';

export const AboutPage: React.FC = () => {
  const { navigate } = useRouter();

  const getPillarIcon = (index: number) => {
    switch (index) {
      case 0:
        return <Compass className="w-6 h-6 text-[#8B5CF6]" />;
      case 1:
        return <Lightbulb className="w-6 h-6 text-[#60A5FA]" />;
      case 2:
        return <Sparkles className="w-6 h-6 text-[#A78BFA]" />;
      case 3:
        return <Accessibility className="w-6 h-6 text-[#7C3AED]" />;
      default:
        return <Heart className="w-6 h-6 text-[#8B5CF6]" />;
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-24 sm:space-y-32">
      {/* 1. HERO SECTION */}
      <section className="space-y-6">
        <Badge variant="lavender" size="md">
          About Zuha Irfan
        </Badge>
        <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-[#1F1B2D] leading-[1.15] max-w-4xl">
          More Than Just{' '}
          <span className="bg-gradient-to-r from-[#8B5CF6] via-[#7C3AED] to-[#60A5FA] bg-clip-text text-transparent">
            Code & Pixels.
          </span>
        </h1>
        <p className="text-lg sm:text-xl text-[#6B6478] leading-relaxed max-w-3xl">
          I am a Software Engineering undergraduate at Fatima Jinnah Women University with a keen passion for product usability and algorithmic problem-solving. My goal is to craft digital tools that are both technically resilient and fundamentally intuitive.
        </p>
      </section>

      {/* 2. MY STORY */}
      <section className="rounded-3xl bg-white border border-[#8B5CF6]/15 p-8 sm:p-14 shadow-xs">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          <div className="lg:col-span-4 space-y-4">
            <span className="text-xs font-semibold tracking-wider text-[#8B5CF6] uppercase block">
              Background & Trajectory
            </span>
            <h2 className="text-3xl font-bold tracking-tight text-[#1F1B2D]">
              My Story
            </h2>
            <div className="p-4 rounded-2xl bg-[#FAF8FF] border border-[#8B5CF6]/15 text-xs text-[#6B6478] space-y-2">
              <div className="flex items-center gap-2 text-[#1F1B2D] font-semibold">
                <MapPin className="w-4 h-4 text-[#8B5CF6]" />
                <span>Rawalpindi, Pakistan</span>
              </div>
              <p>Available for on-site collaborations in Islamabad/Rawalpindi & remote roles worldwide.</p>
            </div>
          </div>

          <div className="lg:col-span-8 space-y-6 text-base text-[#6B6478] leading-relaxed">
            {profileData.bioStory.map((paragraph, idx) => (
              <p key={idx}>{paragraph}</p>
            ))}
          </div>
        </div>
      </section>

      {/* 3. WHAT I CARE ABOUT */}
      <section className="space-y-10">
        <SectionHeading
          badgeText="Core Values"
          title="What I Care"
          highlightWords="About Most"
          description="Guiding principles that steer how I approach every interface, dataset, and architectural decision."
        />

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {profileData.pillars.map((pillar, idx) => (
            <div
              key={pillar.title}
              className="rounded-3xl bg-white border border-[#8B5CF6]/15 p-7 shadow-xs hover:shadow-xl hover:shadow-[#8B5CF6]/10 hover:-translate-y-1 transition-all duration-300 flex flex-col justify-between"
            >
              <div>
                <div className="w-12 h-12 rounded-2xl bg-[#F6F1FF] border border-[#8B5CF6]/20 flex items-center justify-center mb-5">
                  {getPillarIcon(idx)}
                </div>
                <h3 className="text-xl font-bold tracking-tight text-[#1F1B2D] mb-3">
                  {pillar.title}
                </h3>
                <p className="text-sm text-[#6B6478] leading-relaxed">
                  {pillar.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 4. EDUCATION SECTION */}
      <section className="space-y-10">
        <SectionHeading
          badgeText="Academic Foundation"
          title="Formal Education &"
          highlightWords="Credentials"
          description="Academic qualifications in Software Engineering supplemented by continuous self-directed learning."
        />

        <div className="space-y-6">
          {/* Primary Education Card */}
          {profileData.education.filter(e => e.isPrimary).map((edu) => (
            <div
              key={edu.degree}
              className="rounded-3xl bg-gradient-to-br from-white to-[#F6F1FF] border-2 border-[#8B5CF6]/30 p-8 sm:p-12 shadow-sm relative overflow-hidden"
            >
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 mb-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <Badge variant="lavender" size="sm">
                      {edu.status}
                    </Badge>
                    <span className="text-xs text-[#6B6478] font-mono flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5 text-[#8B5CF6]" /> {edu.dates}
                    </span>
                  </div>
                  <h3 className="text-2xl sm:text-3xl font-bold tracking-tight text-[#1F1B2D]">
                    {edu.degree}
                  </h3>
                  <p className="text-base text-[#8B5CF6] font-semibold">
                    {edu.institution}
                  </p>
                  <p className="text-xs text-[#6B6478] flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5" /> {edu.location}
                  </p>
                </div>

                <div className="w-14 h-14 rounded-2xl bg-white shadow-xs border border-[#8B5CF6]/20 flex items-center justify-center text-[#8B5CF6] shrink-0">
                  <GraduationCap className="w-7 h-7" />
                </div>
              </div>

              {edu.details && (
                <div className="pt-4 border-t border-[#8B5CF6]/15 space-y-2">
                  {edu.details.map((d, i) => (
                    <div key={i} className="flex items-start gap-2.5 text-sm text-[#6B6478]">
                      <CheckCircle2 className="w-4 h-4 text-[#8B5CF6] shrink-0 mt-0.5" />
                      <span>{d}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}

          {/* Secondary / Earlier Education (Visually de-emphasized) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
            {profileData.education.filter(e => !e.isPrimary).map((edu) => (
              <div
                key={edu.degree}
                className="rounded-2xl bg-white/70 border border-[#8B5CF6]/10 p-5 shadow-2xs opacity-80 hover:opacity-100 transition-opacity"
              >
                <div className="flex items-center justify-between text-xs text-[#6B6478] mb-1">
                  <span>{edu.dates}</span>
                  <span className="text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full text-[10px] font-medium border border-emerald-200">
                    {edu.status}
                  </span>
                </div>
                <h4 className="text-base font-semibold text-[#1F1B2D]">
                  {edu.degree}
                </h4>
                <p className="text-xs text-[#6B6478] mt-0.5">
                  {edu.institution} • {edu.location}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 5. PERSONAL DESIGN PHILOSOPHY */}
      <section className="rounded-3xl bg-gradient-to-br from-[#1F1B2D] to-[#2D2740] text-white p-8 sm:p-14 shadow-xl border border-[#8B5CF6]/20 relative overflow-hidden">
        <div className="absolute top-6 right-8 text-white/5 pointer-events-none">
          <Quote className="w-32 h-32" />
        </div>

        <div className="relative z-10 max-w-3xl space-y-6">
          <Badge variant="neutral" size="sm" className="bg-white/10 text-purple-200 border-purple-400/30">
            {profileData.designPhilosophy.title}
          </Badge>

          <blockquote className="text-2xl sm:text-3xl font-bold tracking-tight text-white leading-snug">
            &ldquo;{profileData.designPhilosophy.quote}&rdquo;
          </blockquote>

          <p className="text-sm sm:text-base text-white/80 leading-relaxed">
            {profileData.designPhilosophy.description}
          </p>

          <div className="pt-4 flex items-center gap-4">
            <div className="w-10 h-10 rounded-full bg-[#8B5CF6] text-white flex items-center justify-center font-bold text-sm">
              ZI
            </div>
            <div>
              <p className="text-sm font-bold text-white">Zuha Irfan</p>
              <p className="text-xs text-white/60">Software Engineering Student & UI/UX Designer</p>
            </div>
          </div>
        </div>
      </section>

      {/* Bottom Navigation CTA */}
      <section className="flex flex-col sm:flex-row items-center justify-between gap-6 p-8 rounded-3xl bg-white border border-[#8B5CF6]/15 shadow-xs">
        <div>
          <h3 className="text-xl font-bold text-[#1F1B2D]">Interested in working together?</h3>
          <p className="text-sm text-[#6B6478]">Take a look at my project case studies or reach out directly.</p>
        </div>
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={() => navigate('/projects')}
            className="px-5 py-2.5 rounded-full text-sm font-semibold text-white bg-[#8B5CF6] hover:bg-[#7C3AED] transition-colors"
          >
            Explore Projects
          </button>
          <button
            onClick={() => navigate('/contact')}
            className="px-5 py-2.5 rounded-full text-sm font-semibold text-[#1F1B2D] bg-[#FAF8FF] border border-[#8B5CF6]/20 hover:bg-[#F6F1FF] transition-colors"
          >
            Get In Touch
          </button>
        </div>
      </section>
    </div>
  );
};

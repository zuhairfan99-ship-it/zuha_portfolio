import React from 'react';
import { useRouter } from '../context/RouterContext';
import { profileData } from '../data/profile';
import { projectsData } from '../data/projects';
import { experienceData } from '../data/experience';
import { skillsData, heroSkillBadges } from '../data/skills';
import { ProjectCard } from '../components/ProjectCard';
import { ExperienceCard } from '../components/ExperienceCard';
import { SkillCard } from '../components/SkillCard';
import { Badge } from '../components/Badge';
import { SectionHeading } from '../components/SectionHeading';
import { 
  ArrowRight, 
  ArrowUpRight, 
  Github, 
  Linkedin, 
  Mail, 
  Code2, 
  Sparkles, 
  Cpu, 
  Layers, 
  GraduationCap, 
  Briefcase, 
  Terminal,
  CheckCircle2
} from 'lucide-react';
import { motion } from 'motion/react';

export const HomePage: React.FC = () => {
  const { navigate } = useRouter();

  const featuredProjects = projectsData.filter((p) => p.featured).slice(0, 4);
  const previewExperiences = experienceData.slice(0, 3);

  return (
    <div className="space-y-24 sm:space-y-32">
      {/* 1. HERO SECTION */}
      <section className="relative pt-6 sm:pt-12 overflow-hidden">
        {/* Soft background ambient gradient blob */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[550px] h-[350px] bg-gradient-to-tr from-[#DDD6FE]/40 via-[#EDE9FE]/50 to-[#BAE6FD]/30 rounded-full blur-3xl -z-10 pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
            {/* Left Column: Copy & CTAs */}
            <motion.div
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, ease: 'easeOut' }}
              className="lg:col-span-7 space-y-6"
            >
              {/* Badge */}
              <Badge variant="lavender" size="md" icon={<Sparkles className="w-3.5 h-3.5 text-[#8B5CF6]" />}>
                Software Engineering Student
              </Badge>

              {/* Main Heading */}
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-[#1F1B2D] leading-[1.12]">
                Designing & Building{' '}
                <span className="bg-gradient-to-r from-[#8B5CF6] via-[#7C3AED] to-[#60A5FA] bg-clip-text text-transparent">
                  Meaningful Digital Experiences.
                </span>
              </h1>

              {/* Supporting Copy */}
              <p className="text-base sm:text-lg text-[#6B6478] leading-relaxed max-w-2xl">
                Hi, I&apos;m <span className="font-semibold text-[#1F1B2D]">Zuha Irfan</span>. I work across{' '}
                <span className="font-medium text-[#1F1B2D]">UI/UX Design</span>,{' '}
                <span className="font-medium text-[#1F1B2D]">Full-Stack Development</span>,{' '}
                <span className="font-medium text-[#1F1B2D]">AI & Machine Learning</span>, and{' '}
                <span className="font-medium text-[#1F1B2D]">AI Automation</span> — translating complex requirements
                into thoughtful, human-centered systems.
              </p>

              {/* CTA Buttons */}
              <div className="flex flex-wrap items-center gap-3 pt-2">
                <button
                  onClick={() => navigate('/projects')}
                  className="group inline-flex items-center gap-2 px-6 py-3.5 rounded-full text-sm font-semibold text-white bg-gradient-to-r from-[#8B5CF6] to-[#7C3AED] hover:from-[#7C3AED] hover:to-[#6D28D9] shadow-md shadow-[#8B5CF6]/25 hover:shadow-lg hover:shadow-[#8B5CF6]/30 active:scale-[0.98] transition-all cursor-pointer"
                >
                  <span>View My Work</span>
                  <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                </button>

                <button
                  onClick={() => navigate('/about')}
                  className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full text-sm font-semibold text-[#1F1B2D] bg-white border border-[#8B5CF6]/20 hover:bg-[#F6F1FF] hover:border-[#8B5CF6]/40 transition-all cursor-pointer shadow-2xs"
                >
                  <span>About Me</span>
                </button>
              </div>

              {/* Social Links & Quick Contact */}
              <div className="pt-4 flex items-center gap-4 text-xs text-[#6B6478]">
                <span className="font-medium">Connect:</span>
                {profileData.contact.socials.map((s) => (
                  <a
                    key={s.platform}
                    href={s.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 hover:text-[#8B5CF6] transition-colors"
                  >
                    {s.platform === 'GitHub' && <Github className="w-3.5 h-3.5" />}
                    {s.platform === 'LinkedIn' && <Linkedin className="w-3.5 h-3.5" />}
                    <span>{s.platform}</span>
                  </a>
                ))}
                <button
                  onClick={() => navigate('/contact')}
                  className="inline-flex items-center gap-1 hover:text-[#8B5CF6] transition-colors cursor-pointer"
                >
                  <Mail className="w-3.5 h-3.5" />
                  <span>Email</span>
                </button>
              </div>
            </motion.div>

            {/* Right Column: Original Visual Composition with Floating Skill Badges */}
            <motion.div
              initial={{ opacity: 0, scale: 0.96 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6, delay: 0.15 }}
              className="lg:col-span-5 relative"
            >
              <div className="relative mx-auto max-w-[420px] rounded-3xl bg-gradient-to-b from-white to-[#F6F1FF] border border-[#8B5CF6]/20 p-6 sm:p-8 shadow-xl shadow-[#8B5CF6]/10">
                {/* Visual Header / Avatar Representation */}
                <div className="relative w-full aspect-square rounded-2xl bg-gradient-to-br from-[#EDE9FE] via-[#FAF8FF] to-[#DDD6FE] border border-[#8B5CF6]/25 p-6 flex flex-col justify-between overflow-hidden">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full bg-[#8B5CF6]" />
                      <span className="text-xs font-mono font-semibold text-[#1F1B2D]">portfolio_zuha.tsx</span>
                    </div>
                    <span className="text-[11px] font-semibold text-[#8B5CF6] bg-white/90 px-2.5 py-0.5 rounded-full border border-[#8B5CF6]/20">
                      Active Student
                    </span>
                  </div>

                  {/* Tech stack stylized visual center */}
                  <div className="my-auto text-center space-y-3">
                    <div className="w-20 h-20 rounded-2xl bg-white shadow-md mx-auto flex items-center justify-center border border-[#8B5CF6]/20 text-[#8B5CF6]">
                      <Terminal className="w-10 h-10" />
                    </div>
                    <div className="space-y-0.5">
                      <h3 className="text-lg font-bold text-[#1F1B2D]">Zuha Irfan</h3>
                      <p className="text-xs text-[#6B6478]">Software Engineering Undergraduate</p>
                    </div>
                  </div>

                  {/* Bottom metrics */}
                  <div className="grid grid-cols-2 gap-2 pt-2 border-t border-[#8B5CF6]/15 text-center text-xs">
                    <div className="bg-white/80 rounded-xl p-2 border border-[#8B5CF6]/15">
                      <span className="text-[10px] text-[#6B6478] block">Academic Term</span>
                      <span className="font-bold text-[#1F1B2D]">2023 – 2027</span>
                    </div>
                    <div className="bg-white/80 rounded-xl p-2 border border-[#8B5CF6]/15">
                      <span className="text-[10px] text-[#6B6478] block">Internship Focus</span>
                      <span className="font-bold text-[#8B5CF6]">Design & Code</span>
                    </div>
                  </div>
                </div>

                {/* Floating Skill Badges surrounding the visual */}
                <div className="mt-4 flex flex-wrap justify-center gap-2">
                  {heroSkillBadges.map((badge, idx) => (
                    <motion.div
                      key={badge.label}
                      initial={{ y: 0 }}
                      animate={{ y: [0, idx % 2 === 0 ? -4 : 4, 0] }}
                      transition={{
                        duration: 3.5 + idx * 0.5,
                        repeat: Infinity,
                        ease: 'easeInOut',
                      }}
                    >
                      <Badge variant="neutral" size="sm" className="shadow-2xs">
                        <span className="w-1.5 h-1.5 rounded-full bg-[#8B5CF6] mr-1" />
                        {badge.label}
                      </Badge>
                    </motion.div>
                  ))}
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* 2. QUICK INTRO SECTION (Section 7) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="rounded-3xl bg-white border border-[#8B5CF6]/15 p-8 sm:p-12 shadow-xs">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
            {/* Left Column: Visual & Stats composition */}
            <div className="lg:col-span-5 space-y-4">
              <div className="rounded-2xl bg-gradient-to-br from-[#F6F1FF] to-[#EDE9FE] border border-[#8B5CF6]/20 p-6 sm:p-8 text-[#1F1B2D]">
                <div className="w-12 h-12 rounded-2xl bg-white text-[#8B5CF6] flex items-center justify-center shadow-xs mb-4">
                  <GraduationCap className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold tracking-tight text-[#1F1B2D] mb-1">
                  Fatima Jinnah Women University
                </h3>
                <p className="text-sm text-[#6B6478] mb-4">
                  BS in Software Engineering (2023–2027) • Rawalpindi, Pakistan
                </p>
                <div className="space-y-2 text-xs text-[#6B6478]">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-[#8B5CF6]" />
                    <span>Curriculum spanning Data Structures, Web, and DB</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-[#8B5CF6]" />
                    <span>Cross-disciplinary engineering and UX approach</span>
                  </div>
                </div>
              </div>

              {/* Descriptive Stats Cards (No fake numbers!) */}
              <div className="grid grid-cols-2 gap-3">
                <div className="p-4 rounded-2xl bg-[#FAF8FF] border border-[#8B5CF6]/15 text-center">
                  <span className="text-xs text-[#8B5CF6] font-semibold block mb-1">Discipline</span>
                  <p className="text-sm font-bold text-[#1F1B2D]">Software Engineering</p>
                </div>
                <div className="p-4 rounded-2xl bg-[#FAF8FF] border border-[#8B5CF6]/15 text-center">
                  <span className="text-xs text-[#8B5CF6] font-semibold block mb-1">Work History</span>
                  <p className="text-sm font-bold text-[#1F1B2D]">Multiple Internships</p>
                </div>
                <div className="p-4 rounded-2xl bg-[#FAF8FF] border border-[#8B5CF6]/15 text-center">
                  <span className="text-xs text-[#8B5CF6] font-semibold block mb-1">Synergy</span>
                  <p className="text-sm font-bold text-[#1F1B2D]">Design + Development</p>
                </div>
                <div className="p-4 rounded-2xl bg-[#FAF8FF] border border-[#8B5CF6]/15 text-center">
                  <span className="text-xs text-[#8B5CF6] font-semibold block mb-1">Emerging Tech</span>
                  <p className="text-sm font-bold text-[#1F1B2D]">AI & Automation</p>
                </div>
              </div>
            </div>

            {/* Right Column: Narrative intro */}
            <div className="lg:col-span-7 space-y-6">
              <Badge variant="lavender" size="sm">
                About Me
              </Badge>
              <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-[#1F1B2D]">
                Connecting technical structure with empathetic human design.
              </h2>
              <p className="text-base sm:text-lg text-[#6B6478] leading-relaxed">
                {profileData.aboutIntro}
              </p>
              <p className="text-sm sm:text-base text-[#6B6478] leading-relaxed">
                Rather than treating design and software development as isolated silos, I view them as complementary halves of creating great digital products. From early wireframes and user flow mapping to PyTorch predictive modeling and full-stack web integration, I enjoy seeing projects through every stage of development.
              </p>
              <div>
                <button
                  onClick={() => navigate('/about')}
                  className="inline-flex items-center gap-2 text-sm font-semibold text-[#8B5CF6] hover:text-[#7C3AED] group cursor-pointer"
                >
                  <span>More About Me</span>
                  <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 3. FEATURED WORK (Section 8) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <SectionHeading
            badgeText="Featured Work"
            title="Selected Projects &"
            highlightWords="Case Studies"
            description="A curated look into environmental AI systems, clinical prediction models, campus platforms, and user experience research."
          />
          <button
            onClick={() => navigate('/projects')}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-semibold text-[#8B5CF6] bg-white border border-[#8B5CF6]/20 hover:bg-[#F6F1FF] transition-colors shrink-0 cursor-pointer shadow-2xs"
          >
            <span>View All Projects</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {featuredProjects.map((project) => (
            <ProjectCard key={project.slug} project={project} featured />
          ))}
        </div>
      </section>

      {/* 4. EXPERIENCE PREVIEW (Section 9) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <SectionHeading
            badgeText="Professional History"
            title="Experience &"
            highlightWords="Internship Rotations"
            description="Hands-on experience across UI/UX research, machine learning training, full-stack web engineering, and automated workflows."
          />
          <button
            onClick={() => navigate('/experience')}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-semibold text-[#8B5CF6] bg-white border border-[#8B5CF6]/20 hover:bg-[#F6F1FF] transition-colors shrink-0 cursor-pointer shadow-2xs"
          >
            <span>View Full Experience</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* Timeline preview list */}
        <div className="max-w-4xl mx-auto pt-4">
          {previewExperiences.map((item, idx) => (
            <ExperienceCard
              key={item.id}
              experience={item}
              isLast={idx === previewExperiences.length - 1}
            />
          ))}
        </div>
      </section>

      {/* 5. SKILLS PREVIEW (Section 10) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <SectionHeading
            badgeText="Core Competencies"
            title="Categorized Skills &"
            highlightWords="Technical Tooling"
            description="Verified competencies across design methodologies, development languages, AI/ML libraries, and database tools."
          />
          <button
            onClick={() => navigate('/skills')}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-semibold text-[#8B5CF6] bg-white border border-[#8B5CF6]/20 hover:bg-[#F6F1FF] transition-colors shrink-0 cursor-pointer shadow-2xs"
          >
            <span>View All Skills</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* Skills Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {skillsData.map((category) => (
            <SkillCard key={category.title} category={category} />
          ))}
        </div>
      </section>

      {/* 6. CONTACT CTA CARD (Section 11) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative rounded-3xl bg-gradient-to-r from-[#EDE9FE] via-[#FAF8FF] to-[#E0F2FE] border border-[#8B5CF6]/25 p-8 sm:p-14 shadow-lg shadow-[#8B5CF6]/10 text-center overflow-hidden">
          {/* Subtle decorative glow */}
          <div className="absolute -top-24 -right-24 w-72 h-72 bg-[#8B5CF6]/15 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute -bottom-24 -left-24 w-72 h-72 bg-[#60A5FA]/15 rounded-full blur-3xl pointer-events-none" />

          <div className="relative z-10 max-w-2xl mx-auto space-y-6">
            <Badge variant="lavender" size="md">
              Let&apos;s Connect
            </Badge>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-[#1F1B2D]">
              Have an idea? Let&apos;s build something meaningful.
            </h2>
            <p className="text-base sm:text-lg text-[#6B6478] leading-relaxed">
              Whether you are looking for an enthusiastic Software Engineering intern, a UI/UX designer with technical grounding, or a collaborator for an AI project — I would love to hear from you.
            </p>
            <div className="flex flex-wrap items-center justify-center gap-4 pt-2">
              <button
                onClick={() => navigate('/contact')}
                className="inline-flex items-center gap-2 px-7 py-3.5 rounded-full text-sm font-semibold text-white bg-gradient-to-r from-[#8B5CF6] to-[#7C3AED] hover:from-[#7C3AED] hover:to-[#6D28D9] shadow-md shadow-[#8B5CF6]/25 active:scale-[0.98] transition-all cursor-pointer"
              >
                <span>Start a Conversation</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              <button
                onClick={() => navigate('/projects')}
                className="inline-flex items-center gap-2 px-7 py-3.5 rounded-full text-sm font-semibold text-[#1F1B2D] bg-white border border-[#8B5CF6]/20 hover:bg-[#F6F1FF] transition-all cursor-pointer shadow-2xs"
              >
                <span>View My Work</span>
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
